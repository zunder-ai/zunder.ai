export interface ChatMessage {
  isUser: boolean;
  avatar: string;
  content: string;
}
